<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style> 
    body{
        background-color: brown;
    }
    </style>
</head>
<body>
    <h1> Calculadora </h1>
    <script>
        class calculadora {
            suma (n1, n2){
                document.write("Suma")
                let s = 0;
                s = parseInt(n1) + parseInt(n2);
                alert("La suma es: " + s);
            }
            resta (n1, n2){
                document.write("Resta")
                let s=0;
                s = parseInt(n1) - parseInt(n2)
                alert("La resta es: " + s)
                console.log(n1, "-", n2, "=", s)
            }
            multiplicacion (n1, n2){
                document.write("Multiplicacion")
                let s=0;
                s = parseInt(n1) * parseInt(n2)
                alert("La multiplicacion es: " + s)
                console.log(n1, "*", n2, "=", s)
            }
            division (n1, n2){
                document.write("Division")
                let s=0;
                if (n1 < n2){
                    s = parseInt(n1) / parseInt(n2)
                    alert("La division es: " + s)
                    console.log(n1, "/", n2, "=", s)
                } else {
                    s = parseInt(n2) / parseInt(n1)
                    alert("La division es: " + s)
                    console.log(n2, "/", n1, "=", s)
                }
            }
        }
        let calc = new calculadora()
        num1 = prompt("Ingrese el primer numero")
        num2 = prompt("Ingrese el segundo numero")
        calc.suma(num1, num2)
        calc.resta(num1, num2)
        calc.multiplicacion(num1, num2)
        calc.division(num1, num2)
    </script>
</body>
</html>