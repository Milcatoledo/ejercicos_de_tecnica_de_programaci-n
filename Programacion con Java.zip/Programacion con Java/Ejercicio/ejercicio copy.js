class calculadora {
    suma (){
        document.write("Suma")
        let n1 = 0, n2= 0, s = 0;
        n1 = parseFloat(document.getElementById("num1").value)
        n2 = parseFloat(document.getElementById("num2").value)
        let resp = document.getElementById("resp") 
        s = n1 + n2
        let resul = n1.tostring() + " + " + n2.tostring() + " = " + s.tostring()
        resp.textContent = resul
        console.log(n1, "+", n2, "=", s)
    }
    resta (){
        let n1 = 0, n2= 0, s = 0;
        s = parseInt(n1) - parseInt(n2)
        alert("La resta es: " + s)
        console.log(n1, "-", n2, "=", s)
    }
    multiplicacion (){
        let n1 = 0, n2= 0, s = 0;
        s = parseInt(n1) * parseInt(n2)
        alert("La multiplicacion es: " + s)
        console.log(n1, "*", n2, "=", s)
    }
    division (){
        let n1 = 0, n2= 0, s = 0;
        if (n1 < n2){
            s = parseInt(n1) / parseInt(n2)
            alert("La division es: " + s)
            console.log(n1, "/", n2, "=", s)
        } else {
            s = parseInt(n2) / parseInt(n1)
            alert("La division es: " + s)
            console.log(n2, "/", n1, "=", s)
        }
    }
}
let calc = new calculadora()
