class calculadora{
    divisores(){
        let num, divisores= "", i;
        let entrada= document.getElementById("entrada");
        num = parseInt(entrada.value);
            if(isNaN(num)){
                alert("Ingrese un número");
            }
            for(i=1;i<=num;i++){
                if(num%i==0){
                    divisores=divisores+i.toString()+", ";
                }
            }
        entrada.value=`los divisores del número ingresado son: "${divisores}"`
    }
}

let calc = new calculadora();
