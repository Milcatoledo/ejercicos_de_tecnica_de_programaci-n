class calculadora{    
    divisores(){
        let num, divisores="",i;
        let entrada= document.getElementById("entrada");
        console.log(entrada.value);
            num= parseInt(entrada.value);
            if(isNaN(num)){
                alert("Ingrese un número");
            }
            for(i=1;i<=num;i++){
                if(num%i==0){
                    divisores=divisores+i.toString()+", ";
                }
            }
            entrada.value=`los divisores del número ingresado son: "${divisores}"`
        
        
    }
    primos(){
        let num,i,x=0;
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=2;i<=num;i++){
            if(num%i==0){
                x=x+1;
            }
            
        }
        if(x==1){
            entrada.value=`El número ${num} es primo`;
        }else{
            entrada.value=`El número ${num} no es primo`;
        }
    }    
    invertirnum(){
        let num, invertido="", resto;
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        while(num>0){
            resto=num%10;
            invertido=invertido+resto.toString();
            num=Math.floor(num/10);
        }
        entrada.value=invertido;
    }
    perfectos(){
        let num, primos=0,i;
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=1;i<num;i++){
            if(num%i==0){
                primos=primos+i
                console.log(primos);
            }
            if(primos==num){
                entrada.value=`El número ${num} es perfecto`;
            }else{
                entrada.value=`El número ${num} no es perfecto`;
            }
        }
    }
    fibonacci(){
    }   
    Base10_2(){
        let alm=[],resto,num,i,x;
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        x=num;
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=0;num>0;i++){
            resto=num%2;
            alm[i]=resto;
            num=Math.floor(num/2);
        }
        entrada.value=`el número ${x} transformado en binario es: ${alm.reverse().join("")}`
    }
    Base10_8(){
        let alm=[],resto,num,i,x;
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        x=num;
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=0;num>0;i++){
            resto=num%8;
            alm[i]=resto;
            num=Math.floor(num/8);
        }
        entrada.value=`el número ${x} transformado en octal es: ${alm.reverse().join("")}`
    }
    Base10_16(){
        let num,alm=[],resto,i,x, alm2=[];
        let entrada= document.getElementById("entrada");
        num= parseInt(entrada.value);
        x=num;
        if (entrada.value==""){
            alert("Ingrese un número");
        }
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=0;num>0;i++){
            resto=num%16;
            alm[i]=resto;
            num=Math.floor(num/16);
        }
        for (let i=alm.length-1;i>=0;i--){
            switch(alm[i]){
                case 10:
                    alm[i]="A";
                    break;
                case 11:
                    alm[i]="B";
                    break;
                case 12:
                    alm[i]="C";
                    break;
                case 13:
                    alm[i]="D";
                    break;
                case 14:
                    alm[i]="E";
                    break;
                case 15:
                    alm[i]="F";
                    break;
            }
            alm2=alm2+alm[i];
        }
        entrada.value=`el número ${x} transformado en hexadecimal es: ${alm2}`
    }
    Base2_10(){
        let num,alm=[],i,cont=0;
        let entrada= document.getElementById("entrada");
        num= entrada.value;
        if(isNaN(num)){
            alert("Ingrese un número");
        }
        for(i=0;i<num.length;i++){
            alm[i]=num.charAt(i);
        }
        for(i=0;i<alm.length;i++){
            if(alm[i]==1){
                cont=cont+Math.pow(2,alm.length-i-1);
            }
        }
        entrada.value=cont;
    }
    Base2_16(){
    }
    contar_palabras(){
        let frase,cont=0;
        let entrada= document.getElementById("entrada");
        frase= entrada.value;
        for(let i=0;i<frase.length;i++){
            if(frase[i]==" "&&frase[i+1]!=" "){
                cont=cont+1;
            }
        }
        entrada.value=`La frase tiene ${cont+1} palabras`;
    }
    palindromo(){
        let frase,frase2="",frase3="";
        let entrada= document.getElementById("entrada");
        frase= entrada.value;
        for(let i=frase.length-1;i>=0;i--){
            if(frase[i]!=" "){
                frase3=frase[i]+frase3;
                frase2=frase2+frase[i];
                console.log(frase2);
            }
        }
        if(frase3==frase2){
            entrada.value=`La frase "${frase}" es un palíndromo`;
        }
        else{
            entrada.value=`La frase "${frase}" no es un palíndromo`;
        }
    }
    invertir_frase(){
        let frase,frase2="";
        let entrada= document.getElementById("entrada");
        frase= entrada.value;
        for(let i=frase.length-1;i>=0;i--){
            frase2=frase2+frase[i];
        }
        entrada.value=frase2;
    }
    contar_caracteres(){
        let frase,cont=0;
        let entrada= document.getElementById("entrada");
        frase= entrada.value;
        for(let i=0;i<frase.length;i++){
            if(frase[i]!=" "){
                cont=cont+1;
            }
        }
        entrada.value=`La frase tiene ${cont} caracteres`;
    }
    buscar_cadena(){
        let frase,frase2,cont=0;
        let entrada= document.getElementById("entrada");
        frase= entrada.value;
        frase2= prompt("Ingrese la palabra a buscar");
        for(let i=0;i<frase.length;i++){
            if(frase[i]==frase2[0]){
                for(let j=0;j<frase2.length;j++){
                    if(frase[i+j]==frase2[j]){
                        cont=cont+1;
                    }
                }
                if(cont==frase2.length){
                    entrada.value=`La frase si contiene la palabra "${frase2}"`;
                }
                else{
                    entrada.value=`La frase no contiene la palabra "${frase2}"`;
                }
            }
        }
    }
    mayor_de_arreglo(){
    }
    promedio_arreglo(){
        let entrada = document.getElementById("entrada")
        entrada = entrada.value
        let arreglo = entrada.split(",")
        let acumulador = 0
        let contador = 0
        let promedio = 0
        for (let x = 0; x < arreglo.length; x++) {
            acumulador = acumulador + parseFloat(arreglo[x])
            contador = contador + 1
            
        }
        promedio = parseFloat(acumulador/contador)
        resp.textContent=`El promedio del arreglo es: ${promedio}\n`
        
        
    }
    insertar_arreglo(){    
    } 
    buscar_arreglo(){
    }
    eliminar_arreglo(){
    }





}
let calc= new calculadora();