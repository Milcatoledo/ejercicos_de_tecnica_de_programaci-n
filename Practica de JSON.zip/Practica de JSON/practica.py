import json 
archivo = open('directorio.json')
contenido = json.load(archivo)
usuarios = []
cargos_existentes = []
departamentos_existentes = []

def run ():
    departamentosCrear()
    cargosCrear()
    personalCrear()
    presentar()

def departamentosCrear():
    for persona in contenido:
        departamento = persona['departamento']
        if departamento not in departamentos_existentes:
            departamentos_existentes.append(departamento)

def cargosCrear():
    for persona in contenido:
        cargo = persona['cargo']
        if cargo not in cargos_existentes:
            cargos_existentes.append(cargo)

def personalCrear():
    for persona in contenido:
        apellido = persona['apellidos']
        nombres = persona['nombres']
        datos = {
            'apellidos': apellido,
            'nombres': nombres,
            'cargos' : [],
            'departamentos' : []
        }
    if datos not in usuarios:
        usuarios.append(datos)
    cargos1()
    departamentos1()

def cargos1():
    for persona in contenido:
        apellidos = persona['apellidos']
        nombres = persona['nombres']
        cargo = persona['cargo']
        for usuario in usuarios:
            if usuario['apellidos'] == apellidos and usuario['nombres'] == nombres:
                usuario['cargos'].append(cargo)

def departamentos1():
    for persona in contenido:
        apellidos = persona['apellidos']
        nombres = persona['nombres']
        departamento = persona['departamento']
        for usuario in usuarios:
            if usuario['apellidos'] == apellidos and usuario['nombres'] == nombres:
                usuario['departamentos'].append(departamento)
                
def presentar():
    for persona in usuarios:
        apellidos = persona['apellidos']
        nombre = persona['nombres']
        departamentos = persona['departamentos']
        cargos = persona['cargos']
        print("")
        print(f'{apellidos} {nombre}')
        print(f'cargo')
        for cargo in cargos:
            print(f'{cargo}')
        print(f'departamento')
        for departamento in departamentos:
            print(f'{departamento}')
        print("")
        print(f'total de cargos: {len(cargos)}')
        print(f'total de departamentos: {len(departamentos)}')
        print(f'total de usuarios: {len(usuarios)}')
        print("")
        for departamento in departamentos_existentes:
            print(f'{departamento}')
        print(f'total de departamentos: {len(departamentos_existentes)}')
        for cargo in cargos_existentes:
            print(f'{cargo}')
        print(f'total de cargos: {len(cargos_existentes)}')

if __name__ == '__main__':
    run()
    